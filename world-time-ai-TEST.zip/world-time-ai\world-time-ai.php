<?php
/**
 * Plugin Name: World Time AI
 * Version: 0.1.0
 * Description: Minimal test version
 */

add_action('admin_notices', function() {
    echo '<div class="notice notice-success"><p><strong>World Time AI v0.1.0 is ACTIVE!</strong></p></div>';
});
